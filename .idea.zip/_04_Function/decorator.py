'''
Python has an interesting feature called decorators to add functionality to an existing code.

This is also called metaprogramming because a part of the program tries to modify another part of the program at compile time.

Functions can be passed as arguments to another function.
Such functions that take other functions as arguments are also called higher order functions.
'''
'''def inc(x):
    return x + 1


def dec(x):
    return x - 1


def operate(func, x):
    result = func(x)
    return result

print(operate(inc,4))
print(operate(dec,4))

def is_called():
    def is_returned():
        print("world")
        print("Hello")
    return is_returned


new = is_called()


# Outputs "Hello"
new()

def dec(fun):
    def fun1():
        print("Hello")
        fun()
        outfun()
    return fun1
def outfun():
    print("Out Function")
def calleddec():
    print("Callable")

call = dec(calleddec)
call()'''

'''
def dec(fun):
    def fun1():
        print("Hello")
        fun()
    return fun1

@dec
def calleddec():
    print("Callable")
 '''


def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

@make_pretty
def ordinary():
    print("I am ordinary")

ordinary()

def smart_divide(func):
    def inner(a, b):
        print("I am going to divide", a, "and", b)
        if b == 0:
            print("Whoops! cannot divide")
            return

        return func(a, b)
    return inner


@smart_divide
def divide(a, b):
    print(a/b)
divide(4,0)







