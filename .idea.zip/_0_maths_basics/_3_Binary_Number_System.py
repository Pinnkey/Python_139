''''''
'''
Decimal to Binary:
===================
Decimal Number : 137
Convert to binary===>  2| 137
                       2| 68 - 1
                       2| 34 - 0
                       2| 17 - 0 
                       2|  8 - 1 
                       2|  4 - 0
                       2|  2 - 0
                        |  1 - 0           Binary format - 10001001
 
 
 
Binary to Decimal:
=================== 
Given binary  number                :  1  0  0  0  1  0  0  1 
                                       -----------------------
position(0-7) left to right :          7  6  5  4  3  2  1  0 
                                      2  2  2  2  2  2  2  2  
Whereever 1 exists,calcuate power : ----------------------------   
                                    128  0  0  0  8  0  0  1  ==> sum => 137
                                   -----------------------------            
                                                           
'''