#print(i + 4j + 2i + 3j)

'''st = {'first':'XYZ'}
print(st['first'])

print(-3+5)'''
print(21/4)
print(-26/4)